#ifndef __ROOTTASK_H__
#define __ROOTTASK_H__

void RootTask(void);

#endif
