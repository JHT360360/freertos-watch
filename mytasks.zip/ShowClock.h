#ifndef __SHOWCLOCK_H__
#define __SHOWCLOCK_H__

void ShowClockTimeTask(void *params);
void ClockTimerCallBackFun(TimerHandle_t xTimer);

#endif