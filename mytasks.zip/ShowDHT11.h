#ifndef __SHOWDHT11_H__
#define __SHOWDHT11_H__

void ShowDHT11Task(void *params);

#endif
