#ifndef __SHOWFLASHLIGHT_H__
#define __SHOWFLASHLIGHT_H__

void ShowFlashLightTask(void *params);

#endif