#ifndef _SHOWSETTING_H__
#define _SHOWSETTING_H__

void ShowSetting_Task(void *params);

#endif